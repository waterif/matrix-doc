# ubuntu syslog-ng

公司的基础镜像决定采用ubuntu 16.04, 由于部分应用需要将数据写入到syslog, 所以尝试将syslog集成到基础镜像中去。

日志收集系统需要一个完整的架构，不能太乱，这里只是临时尝试，不是最终解决方案。

```
apt-get install syslog-ng

The following additional packages will be installed:
  libdbi1 libesmtp6 libevtlog0 libhiredis0.13 libivykis0 libmongo-client0 libnet1 syslog-ng-core syslog-ng-mod-amqp syslog-ng-mod-geoip syslog-ng-mod-json syslog-ng-mod-mongodb syslog-ng-mod-redis
  syslog-ng-mod-smtp syslog-ng-mod-sql syslog-ng-mod-stomp
Suggested packages:
  rabbitmq-server mongodb-server libdbd-mysql libdbd-pgsql libdbd-sqlite3 activemq
The following packages will be REMOVED:
  rsyslog ubuntu-minimal
The following NEW packages will be installed:
  libdbi1 libesmtp6 libevtlog0 libhiredis0.13 libivykis0 libmongo-client0 libnet1 syslog-ng syslog-ng-core syslog-ng-mod-amqp syslog-ng-mod-geoip syslog-ng-mod-json syslog-ng-mod-mongodb
  syslog-ng-mod-redis syslog-ng-mod-smtp syslog-ng-mod-sql syslog-ng-mod-stomp
0 upgraded, 17 newly installed, 2 to remove and 93 not upgraded.
```

