# Syslog-NG

用于集中日志管理，可以对日志进行筛选过滤。

syslog-ng作为syslog的替代工具，可以完全替代syslog的服务，并且通过定义规则，实现更好的过滤功能。

> 设计原则

syslog-ng替代syslog是基于以下的设计原则的：

- 通过正则表达式协助，除支持原facitily/level方式，还支持内容过滤等以建立更好的消息过滤机制；
- 支持主机链，即使日志消息经过多重网络转发，仍可找到原发出主机的信息和整个消息链；
- 支持强大的自定义配置，并且清晰、明了。

syslog-ng的主配置文件存放在：`/etc/syslog-ng/syslog-ng.conf`

syslog-ng的配置基于下面的架构：

```
LOG STATEMENTS『SOURCES － FILTERS －DESTINATIONS』
消息路径 『消息源 － 过滤器 － 目的站』
```

也就是说，通过定义多个消息源，把匹配上若干个过滤器的消息导向到指定的目的地，从而组成一个消息路径。


## 消息源SOURCES

```
source <sourcename> { sourcedriver params; sourcedriver params; ... };
```

- <sourcename>：一个消息源的标识
- sourcedriver：消息源驱动器，可以支持若干参数，并使用分号";"隔离多个消息源驱动器

消息源驱动器有：

- file (filename) ： 从指定的文件读取日志信息
- unix-dgram (filename) ： 打开指定的SOCK_DGRAM模式的unix套接字，接收日志消息
- unix-stream (filename) ： 打开指定的SOCK_STREAM模式的unix套接字，接收日志消息
- udp ( (ip),(port) ) ： 在指定的UDP端口接收日志消息
- tcp ( (ip),(port) ) ： 在指定的TCP端口接收日志消息
- sun-streams (filename) ： 在solaris系统中，打开一个（多个）指定的STREAM设备，从其中读取日志消息
- internal() ： syslog-ng内部产生的消息
- pipe(filename),fifo(filename) ： 从指定的管道或者FIFO设备，读取日志信息

例如：

```
source s_sys {
   file("/proc/kmsg" log_prefix("kernel: "));
   unix-stream("/dev/log");
   internal();
   # udp(ip(0.0.0.0) port(514)); #如果取消注释，则可以从udp的514端口获取消息
};
```

## 过滤器FILTERS

```
filter <filtername> { expression; };
```

- <filtername>：一个过滤器标识
- expression：表达式

表达式支持：

- 逻辑操作符：and（和）、or（或）、not（非）；
- 函数：可使用正规表达式描述内容

过滤函数有：

- facility(,)： 根据facility（设备）选择日志消息，使用逗号分割多个facility
- level(,)： 根据level（优先级）选择日志消息，使用逗号分割多个level，或使用“..”表示一个范围
- program(regexp)： 日志消息的程序名是否匹配一个正则表达式
- host(regexp)： 日志消息的主机名是否和一个正则表达式匹配
- match(regexp)： 对日志消息的内容进行正则匹配
- filter()： 调用另一条过滤规则并判断它的值

例如：

```
filter f_filter2{ 
  level(info) and
  not facility(mail,authpriv,cron); 
};

另外，filter(DEFAULT)，用于捕获所有没有匹配上的日志消息。

## 参考资料

- [syslog-ng 详解](http://www.360doc.com/content/14/0313/09/16243542_360179097.shtml)