# filebeat安装

filebeat安装比较简单，支持在不同操作系统中进行安装，提供的有deb, rpm安装包，也可以在mac, docker, windows上进行安装。

> deb

```
curl -L -O https://artifacts.elastic.co/downloads/beats/filebeat/filebeat-5.6.4-amd64.deb
sudo dpkg -i filebeat-5.6.4-amd64.deb
```

> rpm

```
curl -L -O https://artifacts.elastic.co/downloads/beats/filebeat/filebeat-5.6.4-x86_64.rpm
sudo rpm -vi filebeat-5.6.4-x86_64.rpm
```

> mac

```
curl -L -O https://artifacts.elastic.co/downloads/beats/filebeat/filebeat-5.6.4-darwin-x86_64.tar.gz
tar xzvf filebeat-5.6.4-darwin-x86_64.tar.gz
```

> docker

```
docker pull docker.elastic.co/beats/filebeat:5.6.4
```

> win

略

由于笔者是为了给k8s集群搭建日志系统，所以我当然采用docker的方式了。由于我预装的ES版本是5.5.2所以filebeat也保持一致。

```
docker pull docker.elastic.co/beats/filebeat:5.5.2
```

filebeat通过yml配置文件配置日志的读取和输出。

对于rpm或者deb来说，配置文件是`/etc/filebeat/filebeat.yml`这个文件，对于mac 和 win来说，请查看解压文件夹。

对于官方提供的docker镜像，配置文件在`/usr/share/filebeat/filebeat.yml`.

官方提供的docker是基于centos系统的，下载下来占用空间大概300多M，还是比较大的，所以我们放弃采用官方提供的，使用社区提供的基于debian系统构建的。

镜像地址：







