# filebeat配置

编辑配置文件来配置filebeat，对于rpm或者deb来说，配置文件是`/etc/filebeat/filebeat.yml`这个文件，对于MAC或者win来说，请查看你的解压文件中。

这里有一个简单的filebeat的配置文件filebeat.yml的样本，filebeat会使用很多默认的选项。

```
filebeat.prospectors:
- input_type: log
  paths:
    - /var/log/*.log
```

让我们来配置filebeat：

1、定义你的日志文件的路径（一个或多个）

对于大多数的基本filebeat配置，你可以定义一个单一探测器针对一个单一的路径，例如：

```
filebeat.prospectors:
- input_type: log
  paths:
    - /var/log/*.log
```

在这个例子中，探测器会收集`/var/log/*.log`的所有匹配文件，这意味这filebeat会收集所有的`/var/log`下以`.log`结尾的文件，此处还支持Golang Glob支持的所有模式。

在预定义级别的子目录中获取所有文件，可以使用这个配置：`/var/log/*/*.log`，这会找到`/var/log`下所有子目录中所有的以`.log`结尾的文件。但它并不会找到`/var/log`文件夹下的以`.log`结尾的文件。现在它还不能递归的在所有子目录中获取所有的日志文件。

2、如果你设置输出到elasticsearch中，那么你需要在filebeat的配置文件中设置elasticsearch的IP地址与端口。

```
output.elasticsearch:
  hosts: ["192.168.1.42:9200"]
```

3、如果要使用logstash对filebeat收集起来的数据执行其他处理，你需要配置filebeat使用logstash。

```
output.logstash:
  hosts: ["127.0.0.1:5044"]
```

4、如果想不通过logstash直接入库到elasticsearch，可注释掉logstash入库部分，直接打开elasticsearch入库部分即可。

```
output.elasticsearch:
  hosts: ["localhost:9200"]
```

## Filebeat Prospectors

filebeat探测器。

```
filebeat.prospectors:
- input_type: log
  paths:
    - /var/log/apache/httpd-*.log

- input_type: log
  paths:
    - /var/log/messages
    - /var/log/*.log
```

### 选项

> input_type

可选值:

- log: Reads every line of the log file (default)
- stdin: Reads the standard in

The value that you specify here is used as the input_type for each event published to Logstash and Elasticsearch.

> paths

A list of glob-based paths that should be crawled and fetched. All patterns supported by Golang Glob are also supported here. For example, to fetch all files from a predefined level of subdirectories, the following pattern can be used: `/var/log/*/*.log`. This fetches all `.log` files from the subfolders of `/var/log`. It does not fetch log files from the `/var/log` folder itself. Currently it is not possible to recursively fetch all files in all subdirectories of a directory.

Filebeat starts a harvester for each file that it finds under the specified paths. You can specify one path per line. Each line begins with a dash (-).

> exclude_lines

排除正则匹配的行。如果定义了multiline属性，则在执行排除行之前先将多行合并为一行。

A list of regular expressions to match the lines that you want Filebeat to exclude. Filebeat drops any lines that match a regular expression in the list. By default, no lines are dropped.

If multiline is also specified, each multiline message is combined into a single line before the lines are filtered by exclude_lines.

The following example configures Filebeat to drop any lines that start with "DBG".

```
filebeat.prospectors:
- paths:
    - /var/log/myapp/*.log
  exclude_lines: ['^DBG']
```

支持的正则表达式：https://www.elastic.co/guide/en/beats/filebeat/5.6/regexp-support.html

> include_lines

包含行。

```
filebeat.prospectors:
- paths:
    - /var/log/myapp/*.log
  include_lines: ['^ERR', '^WARN']
```


If both include_lines and exclude_lines are defined, Filebeat executes include_lines first and then executes exclude_lines. The order in which the two options are defined doesn’t matter. The include_lines option will always be executed before the exclude_lines option, even if exclude_lines appears before include_lines in the config file.

