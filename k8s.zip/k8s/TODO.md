# TODO

> harbor gluster副本存储问题

安装harbor使用glusterfs 副本存储，导致push出现多次重试，部分成功，失败率较低。

glusterfs副本采用并发写的逻辑，超时导致。

提交issue github, 未解决。

目前采用分布式，无副本存储

> k8s日志滚动

https://linux.die.net/man/8/logrotate 

https://v1-8.docs.kubernetes.io/docs/concepts/cluster-administration/logging/

考虑这个

更好的方式是将日志输出到日志搜集平台。

> 存储的问题

```
E1225 17:30:33.505137   27148 glusterfs.go:153] failed to get endpoints logs[an empty namespace may not be set when a resource name is provided]
E1225 17:30:33.505170   27148 reconciler.go:367] Could not construct volume information: MountVolume.NewMounter failed for volume "kubernetes.io/glusterfs/7668e6bd-e93a-11e7-87b3-000c292573b0-logs" (spec.Name: "logs") pod "7668e6bd-e93a-11e7-87b3-000c292573b0" (UID: "7668e6bd-e93a-11e7-87b3-000c292573b0") with: an empty namespace may not be set when a resource name is provided
```

加入TODO。

> k8s集群内调用使用service方式

原来的：

group -> nginx -> msg

需要改进：

group -> msg

需要开发配合更改配置项。

> beego 的忽略大小写  

// TODO 需要金一团队配合。

> nginx请求proxy需要带上host

// TODO 上线，线上的nginx需要配置好proxy host

> loginserver cluster_id 要跟开账号的 cluster_id对应。 

// NOTICE

