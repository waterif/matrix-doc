# Overview

To work with Kubernetes, you use Kubernetes API objects to describe your cluster’s desired state: what applications or other workloads you want to run, what container images they use, the number of replicas, what network and disk resources you want to make available, and more. You set your desired state by creating objects using the Kubernetes API, typically via the command-line interface, `kubectl`. You can also use the `Kubernetes API` directly to interact with the cluster and set or modify your desired state.

Once you’ve set your desired state, the Kubernetes Control Plane works to make the cluster’s current state match the desired state. To do so, Kubernetes performs a variety of tasks automatically–such as starting or restarting containers, scaling the number of replicas of a given application, and more. The Kubernetes Control Plane consists of a collection of processes running on your cluster:

- The `Kubernetes Master` is a collection of three processes that run on a single node in your cluster, which is designated as the master node. Those processes are: `kube-apiserver`, `kube-controller-manager` and `kube-scheduler`.
- Each individual non-master node in your cluster runs two processes:
	- `kubelet`, which communicates with the Kubernetes Master.
	- `kube-proxy`, a network proxy which reflects Kubernetes networking services on each node.

## Kubernetes Objects

The basic Kubernetes objects include:

- Pod
- Service
- Volume
- Namespace

In addition, Kubernetes contains a number of higher-level abstractions called Controllers. Controllers build upon the basic objects, and provide additional functionality and convenience features. They include:

- ReplicaSet
- Deployment
- StatefulSet
- DaemonSet
- Job

