# Busybox 哨兵

用来验证集群工作状态。

```
apiVersion: extensions/v1beta1
kind: DaemonSet
metadata:
  name: busybox
  labels:
    k8s-app: busybox
spec:
  template:
    metadata:
      labels:
        k8s-app: busybox
    spec:
      terminationGracePeriodSeconds: 0
      restartPolicy: Always
      containers:
      - image: busybox
        name: busybox
        imagePullPolicy: IfNotPresent
        command:
        - sleep
        - "86400"
```