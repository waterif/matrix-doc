# PowerDNS 安装

在k8s集群中安装PowerDNS.

```
apiVersion: v1
kind: Service
metadata:
  labels:
    kubernetes.io/name: powerdns
  name: powerdns
  namespace: kube-system
spec:
  type: NodePort
  clusterIP: 10.10.1.2
  ports:
  - name: http
    port: 8080
    targetPort: 8080
  - name: api
    port: 8081
    targetPort: 8081
  - name: dns
    port: 53
    targetPort: 53
    protocol: UDP
  - name: dns-tcp
    port: 53
    targetPort: 53
    protocol: TCP
  selector:
    k8s-app: powerdns
---
apiVersion: extensions/v1beta1
kind: Deployment
metadata:
  name: powerdns
  namespace: kube-system
spec:
  replicas: 1
  template:
    metadata:
      labels:
        k8s-app: powerdns
    spec:
      containers:
      - name: powerdns
        image: 10.255.1.101/infra/docker-powerdns:mysql
        env:
        - name: MYSQL_AUTOCONF
          value: "false"
        - name: MYSQL_HOST
          value: "10.255.1.101"
        - name: MYSQL_USER
          value: "root"
        - name: MYSQL_PWD
          value: "root3306"
        ports:
        - containerPort: 53
          name: dns
          protocol: UDP
        - containerPort: 53
          name: dns-tcp
          protocol: TCP
        - containerPort: 8080
          name: http
          protocol: TCP
        - containerPort: 8081
          name: api
          protocol: TCP
---
apiVersion: extensions/v1beta1
kind: Ingress
metadata:
  name: powerdns
  namespace: kube-system
spec:
  rules:
  - host: powerdns-ui.testk8s.com
    http:
      paths:
      - path: /
        backend:
          serviceName: powerdns
          servicePort: http
  - host: powerdns-api.testk8s.com
    http:
      paths:
      - path: /
        backend:
          serviceName: powerdns
          servicePort: api
```