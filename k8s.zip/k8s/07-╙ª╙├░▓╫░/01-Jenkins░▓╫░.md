# Jenkins 安装

将Jenkins安装在k8s集群中，使用分布式存储。

```
apiVersion: v1
kind: Service
metadata:
  labels:
    kubernetes.io/name: jenkins
  name: jenkins
  namespace: infra
spec:
  type: NodePort
  ports:
  - port: 8080
    targetPort: 8080
    name: http
  - port: 50000
    targetPort: 50000
    nodePort: 50000
    name: agent
  selector:
    k8s-app: jenkins

---
apiVersion: extensions/v1beta1
kind: Deployment
metadata:
  name: jenkins
  namespace: infra
spec:
  replicas: 1
  template:
    metadata:
      labels:
        k8s-app: jenkins
    spec:
      containers:
      - name: jenkins
        image: 10.255.1.101/infra/jenkins:2.96-alpine
        volumeMounts:
        - mountPath: /var/jenkins_home
          name: jenkins-storage
      volumes:
      - name: jenkins-storage
        glusterfs:
          endpoints: glusterfs-cluster
          path: mar/jenkins
      nodeSelector:
        kubernetes.io/hostname: k8s-113
```


Jenkins Ingress 配置


```
apiVersion: extensions/v1beta1
kind: Ingress
metadata:
  name: jenkins-ui
  namespace: infra
spec:
  rules:
  - host: jenkins-ui.testk8s.com
    http:
      paths:
      - path: /
        backend:
          serviceName: jenkins
          servicePort: http
  - host: jenkins-agent.testk8s.com
    http:
      paths:
      - path: /
        backend:
          serviceName: jenkins
          servicePort: agent
```

Jenkins需要的资源比较多，不建议放置在k8s集群中，使用单独的机器部署Jenkins.

> 采用war包的方式安装部署Jenkins.

## 安装JDK

```
apt-get update
apt-get install openjdk-8-jdk
```

配置JAVA_HOME

```
export JAVA_HOME=/usr/lib/jvm/java-1.8.0-openjdk-amd64 
export CLASSPATH=.:$JAVA_HOME/jre/lib/rt.jar:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar 
export PATH=$PATH:$JAVA_HOME/bin
```

## 安装GO

使用tar包进行安装：go1.9.1.linux-amd64.tar.gz

```
tar -C /usr/local -xzf go1.9.1.linux-amd64.tar.gz
```


```
export GOPATH=/usr/local
export PATH=$PATH:/usr/local/go/bin
```


## 安装Maven

```
tar -C /usr/local -xzf apache-maven-3.3.9-bin.tar.gz
```

```
export MAVEN_HOME=/usr/local/apache-maven-3.3.9
export PATH=$PATH:$MAVEN_HOME/bin
```

maven setting.xml配置

```xml
<?xml version="1.0" encoding="UTF-8"?>
<settings xmlns="http://maven.apache.org/SETTINGS/1.0.0"
          xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
          xsi:schemaLocation="http://maven.apache.org/SETTINGS/1.0.0 http://maven.apache.org/xsd/settings-1.0.0.xsd">
  <localRepository>/data/repository</localRepository>
  <pluginGroups>
  </pluginGroups>
  <proxies>
  </proxies>
  <servers>
    <server>
      <id>gnet-central</id>
      <username>admin</username>
      <password>admin123</password>
    </server>
  </servers>
  <mirrors>
    <mirror>
        <id>nexus-aliyun</id>
        <mirrorOf>central,!gnet-central,!qs-public,!spring-snapshots,!spring-milestones</mirrorOf>
        <name>Nexus aliyun</name>
        <url>http://maven.aliyun.com/nexus/content/groups/public/</url>
    </mirror>
  </mirrors>
  <profiles>
    <profile> 
      <id>quanshi</id> 
      <activation>  
      <activeByDefault>true</activeByDefault>  
      <jdk>1.8</jdk>  
      </activation>  
      <properties>  
      <maven.compiler.source>1.8</maven.compiler.source>  
      <maven.compiler.target>1.8</maven.compiler.target>  
      <maven.compiler.compilerVersion>1.8</maven.compiler.compilerVersion>  
      </properties>  
    </profile>
  </profiles>
</settings>
```

## 安装SVN

```
apt install subversion
```

## 安装Git

默认就安装了。

## 安装Tomcat

```
tar -C /usr/local -xzf apache-tomcat-8.5.14.tar.gz
```

```
export CATALINA_HOME=/usr/local/apache-tomcat-8.5.14
export PATH=$PATH:$CATALINA_HOME/bin
```

将Tomcat部署为服务。


> `/etc/init.d/tomcat`

```
#!/bin/bash

### BEGIN INIT INFO
# Provides:        tomcat
# Required-Start:  $network
# Required-Stop:   $network
# Default-Start:   2 3 4 5
# Default-Stop:    0 1 6
# Short-Description: Start/Stop Tomcat server
### END INIT INFO

start() {
  startup.sh
}
 
stop() {
  shutdown.sh                                         
}
 
case $1 in
  start|stop) $1;;
  restart) stop; start;;
  *) echo "Run as $0 &lt;start|stop|restart&gt;"; exit 1;;
esac
```

```
update-rc.d tomcat defaults
```

```
/etc/init.d/tomcat start
```

配置为服务有一些问题，暂时直接通过命令行方式启动吧。

## 配置Jenkins

> Jenkins工作目录

```
export JENKINS_HOME=/data/jenkins
```
