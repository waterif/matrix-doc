# Ingress 配置

将部分内部服务另外添加的Ingress规则集中到这里记录。

## Grafana 监控

```
apiVersion: extensions/v1beta1
kind: Ingress
metadata:
  name: monitoring-grafana
  namespace: kube-system
spec:
  rules:
  - host: grafana.testk8s.com
    http:
      paths:
      - path: /
        backend:
          serviceName: monitoring-grafana
          servicePort: 80
```