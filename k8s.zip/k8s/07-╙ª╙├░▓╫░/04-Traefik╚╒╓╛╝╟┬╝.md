# Traefik 日志记录

```
apiVersion: v1
kind: ServiceAccount
metadata:
  name: ingress
  namespace: kube-system
---

kind: ClusterRoleBinding
apiVersion: rbac.authorization.k8s.io/v1beta1
metadata:
  name: ingress
subjects:
  - kind: ServiceAccount
    name: ingress
    namespace: kube-system
roleRef:
  kind: ClusterRole
  name: cluster-admin
  apiGroup: rbac.authorization.k8s.io

---
apiVersion: v1
kind: ConfigMap
metadata:
  name: traefik-conf
  namespace: kube-system
data:
  traefik.toml: |
    traefikLogsFile = "/logs/traefik.log"
    [accessLog]
    filePath = "/logs/access.log"
    format = "json"

---
apiVersion: extensions/v1beta1
kind: DaemonSet
metadata:
  name: traefik-ingress-lb
  namespace: kube-system
  labels:
    k8s-app: traefik-ingress-lb
spec:
  template:
    metadata:
      labels:
        k8s-app: traefik-ingress-lb
        name: traefik-ingress-lb
    spec:
      terminationGracePeriodSeconds: 60
      hostNetwork: true
      restartPolicy: Always
      serviceAccountName: ingress
      volumes:
      - name: logs
        glusterfs:
          endpoints: glusterfs-cluster
          path: mar/traefik
      - name: config
        configMap:
          name: traefik-conf
      containers:
      - image: 10.255.1.101/library/traefik
        name: traefik-ingress-lb
        volumeMounts:
        - mountPath: "/logs"
          name: "logs"
        - mountPath: "/config"
          name: "config"
        ports:
        - name: http
          containerPort: 80
          hostPort: 80
        - name: admin
          containerPort: 8580
          hostPort: 8580
        args:
        - --configfile=/config/traefik.toml
        - --web
        - --web.address=:8580
        - --kubernetes
```