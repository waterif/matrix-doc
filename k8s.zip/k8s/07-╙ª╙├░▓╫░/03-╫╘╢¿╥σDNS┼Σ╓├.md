# 自定义DNS配置

集群内部使用自定义DNS即 PowerDNS 提供服务。

## kube-dns

```
apiVersion: v1
kind: ConfigMap
metadata:
  name: kube-dns
  namespace: kube-system
data:
  stubDomains: |
    {
    "xx.com": ["10.255.1.102", "10.255.1.115"],
    "uniform.quanshi.com": ["10.255.1.102", "10.255.1.115"],
    "uniform1.quanshi.com": ["10.255.1.102", "10.255.1.115"],
    "meetnow.quanshi.com": ["10.255.1.102", "10.255.1.115"],
    "meetnow1.quanshi.com": ["10.255.1.102", "10.255.1.115"]
    }
```

为了验证DNS解析，配置了一个busybox服务。

```
apiVersion: v1
kind: Pod
metadata:
  name: busybox
  namespace: default
spec:
  containers:
  - image: busybox
    command:
      - sleep
      - "3600"
    imagePullPolicy: IfNotPresent
    name: busybox
  restartPolicy: Always
```

任何时候都可以使用如下命令验证DNS是否解析正常。

```
kubectl exec -ti busybox -- nslookup kubernetes.default
kubectl exec -ti busybox -- nslookup xx.quanshi.com
```

执行结果示例：

```
Server:    10.0.0.10
Address 1: 10.0.0.10

Name:      kubernetes.default
Address 1: 10.0.0.1
```

## coredns

coredns通过配置Corefile指定自定义DNS.

```
Corefile:
.:53 {
    errors
    health
    kubernetes cluster.local 10.10.0.0/16 {
        pods insecure
    }
    proxy testcloud-k8s.quanshi.com 10.10.1.2
    proxy . /etc/resolv.conf
    cache 60
}
```

## dns验证

```
kubectl run -it --rm --restart=Never --image=infoblox/dnstools:latest dnstools
```

## 参考资料

coredns/kube-dns配置subdomain  
https://www.cnblogs.com/iiiiher/p/7988638.html