# Ansible部署k8s集群

在另一个项目中使用Ansible一键离线部署k8s集群。

采用的是1.8.3版本，更安全，更省时。

地址：http://bjgitlab.gnetis.com/forkme/k8s-setup