# 安装dashboard插件

官方文件目录： kubernetes/cluster/addons/dashboard

依赖：
gcr.io/google_containers/kubernetes-dashboard-amd64

我这里使用我私有仓库里的：

qsharbor:5000/library/kubernetes-dashboard-amd64:v1.7.1

```
cd /root/k8s/kubernetes/addons/
mkdir dashboard
cd dashboard

vim dashboard-controller.yaml
apiVersion: extensions/v1beta1
kind: Deployment
metadata:
  name: kubernetes-dashboard
  namespace: kube-system
  labels:
    k8s-app: kubernetes-dashboard
    kubernetes.io/cluster-service: "true"
    addonmanager.kubernetes.io/mode: Reconcile
spec:
  selector:
    matchLabels:
      k8s-app: kubernetes-dashboard
  template:
    metadata:
      labels:
        k8s-app: kubernetes-dashboard
      annotations:
        scheduler.alpha.kubernetes.io/critical-pod: ''
    spec:
      serviceAccountName: dashboard
      containers:
      - name: kubernetes-dashboard
        image: qsharbor:5000/library/kubernetes-dashboard-amd64:v1.7.1
        resources:
          limits:
            cpu: 100m
            memory: 50Mi
          requests:
            cpu: 100m
            memory: 50Mi
        ports:
        - containerPort: 9090
        livenessProbe:
          httpGet:
            path: /
            port: 9090
          initialDelaySeconds: 30
          timeoutSeconds: 30
      tolerations:
      - key: "CriticalAddonsOnly"
        operator: "Exists"

vim dashboard-rbac.yaml
apiVersion: v1
kind: ServiceAccount
metadata:
  name: dashboard
  namespace: kube-system

---

kind: ClusterRoleBinding
apiVersion: rbac.authorization.k8s.io/v1beta1
metadata:
  name: dashboard
subjects:
  - kind: ServiceAccount
    name: dashboard
    namespace: kube-system
roleRef:
  kind: ClusterRole
  name: cluster-admin
  apiGroup: rbac.authorization.k8s.io

vim dashboard-service.yaml
apiVersion: v1
kind: Service
metadata:
  name: kubernetes-dashboard
  namespace: kube-system
  labels:
    k8s-app: kubernetes-dashboard
    kubernetes.io/cluster-service: "true"
    addonmanager.kubernetes.io/mode: Reconcile
spec:
  type: NodePort 
  selector:
    k8s-app: kubernetes-dashboard
  ports:
  - port: 80
    targetPort: 9090

kubectl create -f .
deployment "kubernetes-dashboard" created
serviceaccount "dashboard" created
clusterrolebinding "dashboard" created
service "kubernetes-dashboard" created

kubectl get service kubernetes-dashboard -n kube-system
NAME                   CLUSTER-IP      EXTERNAL-IP   PORT(S)        AGE
kubernetes-dashboard   10.254.35.179   <nodes>       80:31650/TCP   55s
```

dashboard服务运行在NodePort=31650上。

```
kubectl get pods -n kube-system
NAME                                    READY     STATUS    RESTARTS   AGE
kube-dns-2702352322-x9c24               3/3       Running   0          12h
kubernetes-dashboard-1421697414-xzl29   1/1       Running   0          4m

kubectl describe svc kubernetes-dashboard -n kube-system
Name:                   kubernetes-dashboard
Namespace:              kube-system
Labels:                 addonmanager.kubernetes.io/mode=Reconcile
                        k8s-app=kubernetes-dashboard
                        kubernetes.io/cluster-service=true
Annotations:            <none>
Selector:               k8s-app=kubernetes-dashboard
Type:                   NodePort
IP:                     10.254.35.179
Port:                   <unset> 80/TCP
NodePort:               <unset> 31650/TCP
Endpoints:              172.30.62.2:9090
Session Affinity:       None
Events:                 <none>
```

dashboard服务在node2上运行。

```
kubectl cluster-info
Kubernetes master is running at https://10.255.1.94:6443
KubeDNS is running at https://10.255.1.94:6443/api/v1/namespaces/kube-system/services/kube-dns/proxy
kubernetes-dashboard is running at https://10.255.1.94:6443/api/v1/namespaces/kube-system/services/kubernetes-dashboard/proxy

To further debug and diagnose cluster problems, use 'kubectl cluster-info dump'.
```

由于机器上的iptables设置导致我们不能通过宿主机之外的机器访问31650端口。

```
iptables -S
...
-P FORWARD DROP
...
```

在node2机器上执行：

```
iptables -P FORWARD ACCEPT
```

浏览器访问：http://10.255.1.96:31650

