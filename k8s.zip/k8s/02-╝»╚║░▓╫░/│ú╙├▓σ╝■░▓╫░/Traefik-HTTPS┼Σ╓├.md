Traefik HTTPS配置

公司的API在给应用访问的时候，配置的是https, 虽然可以在前置nginx上配置https, 但是还是有兴趣在traefik上体验一把配置https.


> `vim ingress-rbac.yaml`

```yaml
apiVersion: v1
kind: ServiceAccount
metadata:
  name: ingress
  namespace: kube-system

---

kind: ClusterRoleBinding
apiVersion: rbac.authorization.k8s.io/v1beta1
metadata:
  name: ingress
subjects:
  - kind: ServiceAccount
    name: ingress
    namespace: kube-system
roleRef:
  kind: ClusterRole
  name: cluster-admin
  apiGroup: rbac.authorization.k8s.io
```

Traefik 可以采用daemon-set的方式或deployment的方式都是可以的。

> `vim traefik.yaml`

```yaml
apiVersion: extensions/v1beta1
kind: DaemonSet
metadata:
  name: traefik-ingress-lb
  namespace: kube-system
  labels:
    k8s-app: traefik-ingress-lb
spec:
  template:
    metadata:
      labels:
        k8s-app: traefik-ingress-lb
        name: traefik-ingress-lb
    spec:
      terminationGracePeriodSeconds: 60
      hostNetwork: true
      restartPolicy: Always
      serviceAccountName: ingress
      volumes:
      - name: ssl
        secret:
          secretName: traefik-cert
      - name: config
        configMap:
          name: traefik-conf
      containers:
      - image: qsharbor:5000/library/traefik
        name: traefik-ingress-lb
        volumeMounts:
        - mountPath: "/ssl"
          name: "ssl"
        - mountPath: "/config"
          name: "config"
        ports:
        - name: http
          containerPort: 80
          hostPort: 80
        - name: https
          containerPort: 443
          hostPort: 443
        - name: admin
          containerPort: 8580
          hostPort: 8580
        args:
        - --configfile=/config/traefik.toml
        - --web
        - --web.address=:8580
        - --kubernetes
```

```
openssl req -newkey rsa:2048 -nodes -keyout quanshi.com.key  -x509 -days 3650 -out quanshi.com.crt

kubectl create secret generic traefik-cert --from-file=quanshi.com.crt --from-file=quanshi.com.key -n kube-system
```

> `vim traefik.toml`

```
defaultEntryPoints = ["http","https"]
[entryPoints]
  [entryPoints.http]
  address = ":80"
    [entryPoints.http.redirect]
      entryPoint = "https"
  [entryPoints.https]
  address = ":443"
    [entryPoints.https.tls]
      [[entryPoints.https.tls.certificates]]
      CertFile = "/ssl/quanshi.com.crt"
      KeyFile = "/ssl/quanshi.com.key"
```

```
kubectl create configmap traefik-conf --from-file=traefik.toml -n kube-system
```

> `vim ui.yaml`

```yaml
apiVersion: v1
kind: Service
metadata:
  name: traefik-web-ui
  namespace: kube-system
spec:
  selector:
    k8s-app: traefik-ingress-lb
  ports:
  - name: web
    port: 80
    targetPort: 8580
---
apiVersion: extensions/v1beta1
kind: Ingress
metadata:
  name: traefik-web-ui
  namespace: kube-system
spec:
  tls:
    - secretName: traefik-cert
  rules:
  - host: traefik-ui.quanshi.com
    http:
      paths:
      - path: /
        backend:
          serviceName: traefik-web-ui
          servicePort: web
```

安装

```
kubectl create -f ingress-rbac.yaml
kubectl create -f traefik.yaml
kubectl create -f ui.yaml
```

删除

```
kubectl delete -f traefik.yaml
```