安装EFK插件

- gcr.io/google_containers/elasticsearch:v2.4.1-2
- gcr.io/google_containers/fluentd-elasticsearch:1.22
- gcr.io/google_containers/kibana:v4.6.1-1

```
docker pull registry.cn-hangzhou.aliyuncs.com/chinaxiang/elasticsearch:v2.4.1-2
docker pull registry.cn-hangzhou.aliyuncs.com/chinaxiang/fluentd-elasticsearch:1.22
docker pull registry.cn-hangzhou.aliyuncs.com/chinaxiang/kibana:v4.6.1-1
```

```
cd /root/k8s/kubernetes/addons/
mkdir efk
cd efk

vim efk-rbac.yaml
apiVersion: v1
kind: ServiceAccount
metadata:
  name: efk
  namespace: kube-system

---

kind: ClusterRoleBinding
apiVersion: rbac.authorization.k8s.io/v1beta1
metadata:
  name: efk
subjects:
  - kind: ServiceAccount
    name: efk
    namespace: kube-system
roleRef:
  kind: ClusterRole
  name: cluster-admin
  apiGroup: rbac.authorization.k8s.io

vim es-controller.yaml
apiVersion: v1
kind: ReplicationController
metadata:
  name: elasticsearch-logging-v1
  namespace: kube-system
  labels:
    k8s-app: elasticsearch-logging
    version: v1
    kubernetes.io/cluster-service: "true"
    addonmanager.kubernetes.io/mode: Reconcile
spec:
  replicas: 2
  selector:
    k8s-app: elasticsearch-logging
    version: v1
  template:
    metadata:
      labels:
        k8s-app: elasticsearch-logging
        version: v1
        kubernetes.io/cluster-service: "true"
    spec:
      serviceAccountName: efk
      containers:
      - image: qsharbor:5000/library/elasticsearch:v2.4.1-2
        name: elasticsearch-logging
        resources:
          # need more cpu upon initialization, therefore burstable class
          limits:
            cpu: 1000m
          requests:
            cpu: 100m
        ports:
        - containerPort: 9200
          name: db
          protocol: TCP
        - containerPort: 9300
          name: transport
          protocol: TCP
        volumeMounts:
        - name: es-persistent-storage
          mountPath: /data
        env:
        - name: "NAMESPACE"
          valueFrom:
            fieldRef:
              fieldPath: metadata.namespace
      volumes:
      - name: es-persistent-storage
        emptyDir: {}

vim es-service.yaml
apiVersion: v1
kind: Service
metadata:
  name: elasticsearch-logging
  namespace: kube-system
  labels:
    k8s-app: elasticsearch-logging
    kubernetes.io/cluster-service: "true"
    addonmanager.kubernetes.io/mode: Reconcile
    kubernetes.io/name: "Elasticsearch"
spec:
  ports:
  - port: 9200
    protocol: TCP
    targetPort: db
  selector:
    k8s-app: elasticsearch-logging

vim fluentd-es-ds.yaml
apiVersion: extensions/v1beta1
kind: DaemonSet
metadata:
  name: fluentd-es-v1.22
  namespace: kube-system
  labels:
    k8s-app: fluentd-es
    kubernetes.io/cluster-service: "true"
    addonmanager.kubernetes.io/mode: Reconcile
    version: v1.22
spec:
  template:
    metadata:
      labels:
        k8s-app: fluentd-es
        kubernetes.io/cluster-service: "true"
        version: v1.22
      # This annotation ensures that fluentd does not get evicted if the node
      # supports critical pod annotation based priority scheme.
      # Note that this does not guarantee admission on the nodes (#40573).
      annotations:
        scheduler.alpha.kubernetes.io/critical-pod: ''
    spec:
      serviceAccountName: efk
      containers:
      - name: fluentd-es
        image: qsharbor:5000/library/fluentd-elasticsearch:1.22
        command:
          - '/bin/sh'
          - '-c'
          - '/usr/sbin/td-agent 2>&1 >> /var/log/fluentd.log'
        resources:
          limits:
            memory: 200Mi
          requests:
            cpu: 100m
            memory: 200Mi
        volumeMounts:
        - name: varlog
          mountPath: /var/log
        - name: varlibdockercontainers
          mountPath: /var/lib/docker/containers
          readOnly: true
      nodeSelector:
        beta.kubernetes.io/fluentd-ds-ready: "true"
      tolerations:
      - key : "node.alpha.kubernetes.io/ismaster"
        effect: "NoSchedule"
      terminationGracePeriodSeconds: 30
      volumes:
      - name: varlog
        hostPath:
          path: /var/log
      - name: varlibdockercontainers
        hostPath:
          path: /var/lib/docker/containers

vim kibana-controller.yaml
apiVersion: extensions/v1beta1
kind: Deployment
metadata:
  name: kibana-logging
  namespace: kube-system
  labels:
    k8s-app: kibana-logging
    kubernetes.io/cluster-service: "true"
    addonmanager.kubernetes.io/mode: Reconcile
spec:
  replicas: 1
  selector:
    matchLabels:
      k8s-app: kibana-logging
  template:
    metadata:
      labels:
        k8s-app: kibana-logging
    spec:
      serviceAccountName: efk
      containers:
      - name: kibana-logging
        image: qsharbor:5000/library/kibana:v4.6.1-1
        resources:
          # keep request = limit to keep this container in guaranteed class
          limits:
            cpu: 100m
          requests:
            cpu: 100m
        env:
          - name: "ELASTICSEARCH_URL"
            value: "http://elasticsearch-logging:9200"
          - name: "KIBANA_BASE_URL"
            value: "/api/v1/namespaces/kube-system/services/kibana-logging/proxy"
        ports:
        - containerPort: 5601
          name: ui
          protocol: TCP

vim kubana-service.yaml
apiVersion: v1
kind: Service
metadata:
  name: kibana-logging
  namespace: kube-system
  labels:
    k8s-app: kibana-logging
    kubernetes.io/cluster-service: "true"
    addonmanager.kubernetes.io/mode: Reconcile
    kubernetes.io/name: "Kibana"
spec:
  ports:
  - port: 5601
    protocol: TCP
    targetPort: ui
  selector:
    k8s-app: kibana-logging
```

给 Node 设置标签定义 DaemonSet  fluentd-es-v1.22  时设置了 nodeSelector `beta.kubernetes.io/fluentd-ds-ready=true`  ，所以需要在期望运行 fluentd的 Node 上设置该标签；

```
kubectl get nodes
NAME      STATUS    AGE       VERSION
node1     Ready     12d       v1.7.8
node2     Ready     12d       v1.7.8

kubectl label nodes node1 beta.kubernetes.io/fluentd-ds-ready=true
node "node1" labeled
kubectl label nodes node2 beta.kubernetes.io/fluentd-ds-ready=true
node "node2" labeled

kubectl describe nodes node1
Name:                   node1
Role:
Labels:                 beta.kubernetes.io/arch=amd64
                        beta.kubernetes.io/fluentd-ds-ready=true
                        beta.kubernetes.io/os=linux
                        kubernetes.io/hostname=node1


kubectl create -f .
serviceaccount "efk" created
clusterrolebinding "efk" created
replicationcontroller "elasticsearch-logging-v1" created
service "elasticsearch-logging" created
daemonset "fluentd-es-v1.22" created
deployment "kibana-logging" created
service "kibana-logging" created


kubectl get deployment -n kube-system|grep kibana
kibana-logging         1         1         1            1           51s

kubectl get pods -n kube-system|grep -E 'elasticsearch|fluentd|kibana'
elasticsearch-logging-v1-k9gcq          1/1       Running   0          1m
elasticsearch-logging-v1-mx1dx          1/1       Running   0          1m
fluentd-es-v1.22-gpg31                  1/1       Running   0          1m
fluentd-es-v1.22-tvp9l                  1/1       Running   0          1m
kibana-logging-3907787319-gls91         1/1       Running   0          1m


kubectl get service -n kube-system|grep -E 'elasticsearch|kibana'
elasticsearch-logging   10.254.153.100   <none>        9200/TCP                        2m
kibana-logging          10.254.186.128   <none>        5601/TCP                        2m

kubectl cluster-info

https://10.255.1.94:6443/api/v1/namespaces/kube-system/services/kibana-logging/proxy
http://10.255.1.94:8080/api/v1/namespaces/kube-system/services/kibana-logging/proxy

```


