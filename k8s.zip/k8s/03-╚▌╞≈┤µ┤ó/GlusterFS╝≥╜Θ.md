# GlusterFS 简介

以 Docker 为代表的容器技术在云计算领域正扮演着越来越重要的角色，甚至一度被认为是虚拟化技术的替代品。企业级的容器应用常常需要将重要的数据持久化，方便在不同容器间共享。为了能够持久化数据以及共享容器间的数据，Docker 提出了 Volume 的概念。单机环境的数据卷难以满足 Docker 集群化的要求，因此需要引入分布式文件系统。目前开源的分布式文件系统有许多，例如 GFS，Ceph，HDFS，FastDFS，GlusterFS 等。GlusterFS 因其部署简单、扩展性强、高可用等特点，在分布式存储领域被广泛使用。本文主要介绍了如何利用 GlusterFS 为 Docker 集群提供可靠的分布式文件存储。

## GlusterFS 概述

GlusterFS (Gluster File System) 是一个开源的分布式文件系统，主要由 Z RESEARCH 公司负责开发。GlusterFS 是 Scale-Out 存储解决方案 Gluster 的核心，具有强大的横向扩展能力，通过扩展能够支持数PB存储容量和处理数千客户端。GlusterFS 借助 TCP/IP 或 InfiniBand RDMA 网络将物理分布的存储资源聚集在一起，使用单一全局命名空间来管理数据。GlusterFS 基于可堆叠的用户空间设计，可为各种不同的数据负载提供优异的性能。

GlusterFS 总体架构与组成部分如图1所示，它主要由存储服务器（Brick Server）、客户端以及 NFS/Samba 存储网关组成。不难发现，GlusterFS 架构中没有元数据服务器组件，这是其最大的设计优点，对于提升整个系统的性能、可靠性和稳定性都有着决定性的意义。

图1. GlusterFS 总体架构

![](../img/image001.png)

如图 1 中 GlusterFS 有非常多的术语，理解这些术语对理解 GlusterFS 的动作机理是非常重要的，表1给出了 GlusterFS 常见的名称及其解释。

表1. GlusterFS 常见术语

名称 | 解释
--- | ---
Brick | 最基本的存储单元，表示为trusted storage pool中输出的目录，供客户端挂载用。可以通过主机名和目录名来标识，如'SERVER:EXPORT'
Volume | 一个卷。在逻辑上由N个bricks组成。
Glusterd | Gluster management daemon，要在trusted storage pool中所有的服务器上运行。
FUSE | Filesystem Userspace是一个可加载的内核模块，其支持非特权用户创建自己的文件系统而不需要修改内核代码。通过在用户空间运行文件系统的代码通过FUSE代码与内核进行桥接。
GFID | GFS卷中的每个文件或目录都有一个唯一的128位的数据相关联，其用于模拟inode
Namespace | 每个Gluster卷都导出单个ns作为POSIX的挂载点
Node | 一个拥有若干brick的设备
RDMA | 远程直接内存访问，支持不通过双方的OS进行直接内存访问。
RRDNS | round robin DNS是一种通过DNS轮转返回不同的设备以进行负载均衡的方法
Self-heal | 用于后台运行检测复本卷中文件和目录的不一致性并解决这些不一致。
Volfile | glusterfs进程的配置文件，通常位于/var/lib/glusterd/vols/volname

## 安装

### 配置要求

硬件要求

GlusterFS支持大多数的符合商业标准的x86-64bit硬件平台。存储可以是直接附加的存储，RAID盘，以SATA/SAS/FC盘做后端的FC/Infiniband/iSCSI SAN盘。

网路要求

GlusterFS支持千兆网，百兆网和Infiniband（光纤）。

操作系统要求

GlusterFS可以支持很多POSIX兼容的系统，如GNU/Linux, FreeBSD, OpenSolaris, Solaris, 和Mac OS X。Gluster建议采用Ext3, Ext4或者ZFS作为子系统磁盘的格式。Gluster对GNU/Linux, Mac OS X, FreeBSD和OpenSolaris有内嵌的支持。

### Ubuntu下安装

```
apt-get install software-properties-common
add-apt-repository ppa:gluster/glusterfs-3.13
apt-get update
apt-get install glusterfs-server
```

### CentOS安装

未验证，摘自网络。

```
#安装依赖工具  
yum install xfsprogs wget  
yum install fuse fuse-libs  
#格式化磁盘并创建GFS分区  
fdisk /dev/sdb  
mkfs.xfs -i size=512 /dev/sdb1  
mount /dev/sdb1 /mnt/sdb1  
#安装gluster  
wget http://download.gluster.org/pub/gluster/glusterfs/LATEST/CentOS/gluster-epel.repo -O /etc/yum.repo.d/glusterfs.repo  
yum install glusterfs{,-server,-fuse,-geo-replication}  
#启动glusterfs  
/etc/init.d/glusterd start  
/etc/init.d/glusterd stop  
#如果需要在系统启动时开启glusterd  
chkconfig glusterd on
```

### Gluster源码安装

下载地址：https://download.gluster.org/pub/gluster/glusterfs/

```
./configure  
make  
make install 
```

未验证，需要安装必要的依赖包。

### Gluster安装包

这是ubuntu的包。

下载地址：http://ppa.launchpad.net/gluster/glusterfs-3.13/ubuntu/pool/main/g/glusterfs/

下载如下包：

- http://ppa.launchpad.net/gluster/glusterfs-3.13/ubuntu/pool/main/g/glusterfs/glusterfs-client_3.13.0-ubuntu1~xenial1_amd64.deb
- http://ppa.launchpad.net/gluster/glusterfs-3.13/ubuntu/pool/main/g/glusterfs/glusterfs-common_3.13.0-ubuntu1~xenial1_amd64.deb
- http://ppa.launchpad.net/gluster/glusterfs-3.13/ubuntu/pool/main/g/glusterfs/glusterfs-dbg_3.13.0-ubuntu1~xenial1_amd64.deb
- http://ppa.launchpad.net/gluster/glusterfs-3.13/ubuntu/pool/main/g/glusterfs/glusterfs-server_3.13.0-ubuntu1~xenial1_amd64.deb

使用如下命令安装：

```
dpkg -i glusterfs-xxxx.deb
```

注意: 在安装的时候会有一些依赖的包，如果这些包还没有安装，可以去ubuntu下载网址中，下载需求的包。

下载地址如下：http://archive.ubuntu.com/ubuntu/pool/main/

### 验证安装

安装完成后，在`/usr/sbin`目录下会有如下可执行文件：

- gluster: 控制台管理程序（Gluster Console Manager），可以以命令形式或者交互式形式对glusterfs中的volume，brick，集群节点等信息進行查看及操作（增，刪，改）。
- glusterd: 软链接指向glusterfsd，Glusterfs的管理进程，负责处理来自gluster的命令。
- glusterfs: 软链接指向glusterfsd，Glusterfs自带的客戶端
- glusterfsd: Glusterfs服务端程序

执行：

```
gluster --version
glusterfs --version
systemctl status glusterd
```

查看运行端口

````
ps -ef | grep gluster
netstat -pan | grep glus
```

## 搭建集群

在创建volume之前需要先将一组存储设备组成一个存储池，通过存储设备提供的bricks来组成卷。

在设备上启动glusterd之后，可通过设备的主机名或IP地址，将设备加到存储池中。

```
gluster peer probe [host|ip]  
gluster peer status           #查看除本机外的其他设备状态  
gluster peer detach [host|ip] #如果希望将某设备从存储池中删除 
```

gluster对于每个节点都会生成一个UUID来标识，因此如果节点的IP或主机名发生了变化，只需要重新执行peer probe即可。不过如果一个主机名曾经用过，想再改回去，则gluster会提示已经保存过。此时只能把节点detach掉，然后重新probe。

## GlusterFS卷类型

为了满足不同应用对高性能、高可用的需求，GlusterFS 支持 7 种卷，即 distribute 卷、stripe 卷、replica 卷、distribute stripe 卷、distribute replica 卷、stripe Replica 卷、distribute stripe replica 卷。其实不难看出，GlusterFS 卷类型实际上可以分为 3 种基本卷和 4 种复合卷，每种类型的卷都有其自身的特点和适用场景。

### (1) distribute volume 分布式卷

基于 Hash 算法将文件分布到所有 brick server，只是扩大了磁盘空间，不具备容错能力。由于distribute volume 使用本地文件系统，因此存取效率并没有提高，相反会因为网络通信的原因使效率有所降低，另外本地存储设备的容量有限制，因此支持超大型文件会有一定难度。图2 是 distribute volume 示意图。

图2. Distribute volume示意图

![](../img/image002.jpg)

```
gluster volume create dv-volume node1:/media node2:/media node3:/media ...  
```

### (2) stripe volume 条带卷

类似 RAID0，文件分成数据块以 Round Robin 方式分布到 brick server 上，并发粒度是数据块，支持超大文件，大文件的读写性能高。图3 是 stripe volume 示意图。

图3. Stripe volume示意图

![](../img/image003.jpg)

```
gluster volume create sv-volume stripe 2 node1:/media node2:/media
```

stripe后的参数指明切片的分布位置个数

注意：brick的个数必须等于分布位置的个数

### (3) replica volume 复制卷

文件同步复制到多个 brick 上，文件级 RAID1，具有容错能力，写性能下降，读性能提升。Replicated 模式，也称作 AFR（Auto File Replication），相当于 RAID1，即同一文件在多个镜像存储节点上保存多份，每个 replicated 子节点有着相同的目录结构和文件，replica volume 也是在容器存储中较为推崇的一种。图4 是 replica volume 示意图。

图4 . Replica volume示意图

![](../img/image004.jpg)

```
gluster volume create rv-volume repl 2  node1:/media node2:/media 
```

注意：在创建复本卷时，brick数量与复本个数必须相等；否则将会报错。

另外如果同一个节点提供了多个brick，也可以在同一个结点上创建复本卷，但这并不安全，因为一台设备挂掉，其上面的所有brick就无法访问了。

### (4) distribute stripe volume 分布式条带卷

Brick server 数量是条带数的倍数，兼具 distribute 和 stripe 卷的特点。分布式的条带卷，volume 中 brick 所包含的存储服务器数必须是 stripe 的倍数(>=2倍)，兼顾分布式和条带式的功能。每个文件分布在四台共享服务器上，通常用于大文件访问处理，最少需要 4 台服务器才能创建分布条带卷。图5 是distribute stripe volume 示意图。

图5 . Distribute stripe volume 示意图

![](../img/image005.jpg)

```
gluster volume create dsv-volume stripe 2 node1:/exp1 node1:/exp2 [&] node2:/exp3 node2:/exp4
```

注意：

切片卷的组成依赖于指定brick的顺序
brick必须为分片数K的N倍,brick列表将以K个为一组，形成N个切片卷

### (5) distribute replica volume 分布式复制卷

Brick server 数量是镜像数的倍数，兼具 distribute 和 replica 卷的特点,可以在 2 个或多个节点之间复制数据。分布式的复制卷，volume 中 brick 所包含的存储服务器数必须是 replica 的倍数(>=2倍)，兼顾分布式和复制式的功能。图6 是 distribute replica volume 示意图。

图6 . Distribute replica volume 示意图

![](../img/image006.jpg)

```
gluster volume create drv-volume repl 2 node1:/exp1 node2:/exp2 node3:/exp3 node4:/exp4 
```

注意：

复本卷的组成依赖于指定brick的顺序
brick必须为复本数K的N倍,brick列表将以K个为一组，形成N个复本卷

### (6) stripe replica volume 条带复制卷

类似 RAID 10，同时具有条带卷和复制卷的特点。图7 是 distribute replica volume 示意图。

图7 . Stripe replica volume 示意图

![](../img/image007.png)

```
gluster volume create srv-volume stripe 2 replica 2 server1:/exp1 server2:/exp2 server3:/exp3 server4:/exp4
```

exp1和exp2组成复本卷，exp3和exp4组成复本卷，两个复本卷组成分片卷。

注意：brick数量必须和stripe个数N和repl参数M的积N*M相等。即对于brick列表，将以M为一组，形成N个切片卷。数据切片分布在N个切片卷上，在每个切片卷内部，切片数据复本M份。

### (7) distribute stripe replica volume：分布式条带复制卷

三种基本卷的复合卷，通常用于类 Map Reduce 应用。图8 是 distribute stripe replica volume 示意图。

图8 . Distribute stripe replica volume 示意图

![](../img/image008.png)

```
gluster volume create dsrv-volume stripe 2 replica 2 server1:/exp1 server2:/exp2 server3:/exp3 server4:/exp4 server5:/exp5 server6:/exp6 server7:/exp7 server8:/exp8
```

注意：bricks数量为stripe个数N，和repl个数M的积N*M的整数倍，
exp1 exp2 exp3 exp4组成一个分布卷，exp1和exp2组成一个stripe卷，exp3和exp4组成另一个stripe卷，1和2，3和4互为复本卷
exp4-exp8组成另一个分布卷

## Gluster卷操作

上面我们知道了Gluster的卷类型及创建方式，下面我们来了解Gluster的卷的其他操作。

### 启/停/删除卷

```
gluster volume start mamm-volume
gluster volume stop mamm-volume
gluster volume delete mamm-volume
```

### 扩展收缩卷

```
gluster volume add-brick mamm-volume brick1...  
gluster volume remove-brick mamm-volume brick1... 
```

扩展或收缩卷时，也要按照卷的类型，加入或减少的brick个数必须满足相应的要求。

### 迁移卷

主要完成数据在卷之间的在线迁移

```
gluster volume replace-brick mamm-volume old-brick new-brick [start|pause|abort|status|commit]  
#迁移需要完成一系列的事务，假如我们准备将mamm卷中的brick3替换为brick5  

#启动迁移过程  
$gluster volume replace-brick mamm-volume node3:/exp3 node5:/exp5 start  
#暂停迁移过程  
$gluster volume replace-brick mamm-volume node3:/exp3 node5:/exp5 pause  
#中止迁移过程  
$gluster volume replace-brick mamm-volume node3:/exp3 node5:/exp5 abort  
#查看迁移状态  
$gluster volume replace-brick mamm-volume node3:/exp3 node5:/exp5 status  
#迁移完成后提交完成  
$gluster volume replace-brick mamm-volume node3:/exp3 node5:/exp5 commit   
```

### 均衡卷

当对卷进行了扩展或收缩后，需要对卷的数据进行重新均衡。

```
gluster volume rebalane mamm-volume [start|stop|status]
```

### 卷配额

可以限制卷的大小。

```
gluster volume quota VOLNAME enable
gluster volume quota VOLNAME disable
gluster volume quota VOLNAME limit-usage DIR HARD_LIMIT
gluster volume quota VOLNAME list
gluster volume quota VOLNAME list DIR
gluster volume quota VOLNAME remove DIR

# eg.
gluster volume quota test-volume limit-usage /data 10GB

gluster volume quota test-volume list
/data    10 GB       6 GB
/data1   10 GB       4 GB
gluster volume quota test-volume list /data
/data    10 GB       6 GB
gluster volume quota test-volume remove /data
Usage limit set on /data is removed
```

### 触发副本自愈

```
gluster volume heal mamm-volume #只修复有问题的文件  
gluster volume heal mamm-volume full #修复所有文件  
gluster volume heal mamm-volume info #查看自愈详情  
gluster volume heal mamm-volume info [healed|heal-failed|split-brain]
```

## 监控

我们可以通过多种方式监控Gluster集群。

### 性能profile

```
gluster volume profile mamm-vol start    
gluster volume profile mamm-vol info   
gluster volume profile mamm-vol stop  
```

### 实时top

显示当前某个brick或NFS文件打开/读/写/打开目录/读目录的计数

```
gluster volume top mamm-vol [open|read|write|opendir|readdir] [brick ] [list-cnt ]

gluster volume top mamm-vol [read-perf|write-perf] [bs  count ] [brick ] [list-cnt ] 
```

For example, to view read performance on brick `server:/export/` of test-volume, 256 block size of count 1, and list count 10:

```
gluster volume top test-volume read-perf bs 256 count 1 brick server:/export list-cnt 10
```

### 内部计数导出

```
gluster volume statedump mamm-vol
# 设置导出路径
gluster volume set server.statedump-path /var/log/
# 查看导出数据
gluster volume info dumpfile
```

### 卷状态查看

```
gluster volume status [all|volname] [detail|clients|mem|fd|inode|callpoll]
```

## 垃圾回收

回收站很好理解，用过windows, mac等图形系统的都知道的。默认情况下，每个brick都会有一个隐藏文件夹`.trashcan`用来存放删除的文件。为了避免名字冲突，回收站的文件都会在文件名后追加时间戳。

### 操作

启用/禁用回收站。默认关闭。

```
gluster volume set <VOLNAME> features.trash <on / off>
```

设置回收站目录，默认为`.trashcan`

```
gluster volume set <VOLNAME> features.trash-dir <name>
```

设置回收站的单文件最大值，超过这个值的文件会被直接删除不会进入到回收站，可选的单位：KB, MB, GB, 默认为5MB。另外，大于1GB的文件不会进入回收站，即使设置的最大值大于1GB.

```
gluster volume set <VOLNAME> features.trash-max-filesize <size>
```

排除指定路径，这些路径的文件不会进入回收站。

```
gluster volume set <VOLNAME> features.trash-eliminate-path <path1> [ , <path2> , . . . ]
```

## 事件回调

gluster支持配置事件回调服务。

```
systemctl enable glustereventsd
systemctl start glustereventsd
systemctl status glustereventsd
```

### Status

```
gluster-eventsapi status
```

### Webhooks

我们可以配置一个HTTP回调地址，当Gluster有事件变更时会向配置的地址发送事件通知。

```
usage: gluster-eventsapi webhook-test [-h] [--bearer_token BEARER_TOKEN] url

positional arguments:
  url                   URL of Webhook

optional arguments:
  -h, --help            show this help message and exit
  --bearer_token BEARER_TOKEN, -t BEARER_TOKEN
                        Bearer Token


gluster-eventsapi webhook-test http://192.168.122.188:9000/listen

```

如果WEBHOOK_STATUS OK, 可以注册回调地址。

```
usage: gluster-eventsapi webhook-add [-h] [--bearer_token BEARER_TOKEN] url

positional arguments:
  url                   URL of Webhook

optional arguments:
  -h, --help            show this help message and exit
  --bearer_token BEARER_TOKEN, -t BEARER_TOKEN
                        Bearer Token

gluster-eventsapi webhook-add http://192.168.122.188:9000/listen
```

Note: If `Sync status` is Not OK for any node, then make sure to run following command from a peer node when that node comes up.

```
gluster-eventsapi sync
```

删除回调

```
usage: gluster-eventsapi webhook-del [-h] url

positional arguments:
  url         URL of Webhook

optional arguments:
  -h, --help  show this help message and exit

gluster-eventsapi webhook-del http://192.168.122.188:9000/listen
```

### Configuration

查看配置

```
usage: gluster-eventsapi config-get [-h] [--name NAME]

optional arguments:
  -h, --help   show this help message and exit
  --name NAME  Config Name
```

设置

```
usage: gluster-eventsapi config-set [-h] name value

positional arguments:
  name        Config Name
  value       Config Value

optional arguments:
  -h, --help  show this help message and exit
```

重置

```
usage: gluster-eventsapi config-reset [-h] name

positional arguments:
  name        Config Name or all

optional arguments:
  -h, --help  show this help message and exit
```

### 新增节点

当新增节点的时候，需要执行如下两步，确保新节点也启用事件回调。

1. Enable and Start Eventsd in the new node using the steps mentioned above
2. Run gluster-eventsapi sync command from a peer node other than the new node.

### 事件简介

回调的内容格式如下：

Attribute |  Description
--- | ---
nodeid |  Node UUID
ts |  Event Timestamp
event |  Event Type
message |  Event Specific Data

```
{
    "nodeid": "95cd599c-5d87-43c1-8fba-b12821fd41b6",
    "ts": 1468303352,
    "event": "VOLUME_CREATE",
    "message": {
        "name": "gv1"
    }
}
```

事件类型及消息体参见：http://docs.gluster.org/en/latest/Administrator%20Guide/Events%20APIs/#apis-documentation

## Have a try

实践一下吧。

这里有3台节点：

- 10.211.55.11
- 10.211.55.12
- 10.211.55.14

### 创建一个分布式卷

在三个节点上创建目录：

```
mkdir -p /data/glusterfs/dv/brick1/brick
```

在其中一个节点`10.211.55.11`上执行：

```
gluster volume create dv 10.211.55.12:/data/glusterfs/dv/brick1/brick 10.211.55.14:/data/glusterfs/dv/brick1/brick force
gluster volume info
gluster volume start dv
gluster volume info
mount -t glusterfs 10.211.55.11:/dv /data/glusterfs/dv/brick1/brick

cd /data/glusterfs/dv/brick1/brick
for i in `seq -w 1 100`; do echo test-$i > test-$i; done
```

验证是否分布存储。

### 创建一个分布式分片复制卷

创建一个2分片，3复本，2分布，总计2*3*2=12个brick的卷。

在三个节点上创建目录：

```
mkdir -p /data/glusterfs/dsrv/brick{1..4}/brick
```

在其中一个节点`10.211.55.11`上执行：

```
gluster volume create dsrv stripe 2 replica 3 10.211.55.1{1,2}:/data/glusterfs/dsrv/brick{1..4}/brick 10.211.55.14:/data/glusterfs/dsrv/brick{1..4}/brick force
gluster volume info
gluster volume start dsrv
gluster volume info

mkdir -p /tmp/dsrv
cd /tmp/dsrv
mount -t glusterfs 10.211.55.11:/dsrv /tmp/dsrv
for i in `seq -w 1 12`; do echo test-$i > test-$i; done
```

## 最佳实践

收集的一些好的实践经验，针对生产环境。

### Brick命名

brick是gluster的最小处理单元，每个卷volume可以包含一个或多个brick, brick在服务端的设计推荐采用如下方式。

```
/data/glusterfs/<volume>/<brick>/brick
```

`<brick>` 为挂载的磁盘。

假设有2台机器server1, server2，每台挂载2个存储磁盘sdb1, sdc1.

在2台机器上执行：

```
mkdir -p /data/glusterfs/myvol/brick{1,2}
mount /dev/sdb1 /data/glusterfs/myvol/brick1
mount /dev/sdc1 /data/glusterfs/myvol/brick2
```

在其中一台机器上执行即可：

```
gluster volume create myvol replica 2 \
  server{1..2}:/data/glusterfs/myvol/brick1/brick \
  server{1..2}:/data/glusterfs/myvol/brick2/brick
```

这样myvol卷就得到4个存储位置，两个一组。

### 卷类型选择

分片卷并发粒度是数据块，支持超大文件，大文件的读写性能高。

复本卷具有容错能力，写性能下降，读性能提升。Replicated 模式，也称作 AFR（Auto File Replication），相当于 RAID1，即同一文件在多个镜像存储节点上保存多份，每个 replicated 子节点有着相同的目录结构和文件，replica volume 也是在容器存储中较为推崇的一种。

在生产环境中使用dsrv是最好的选择，兼顾高可用高性能易扩展。

比较推荐的卷配置为：

- `stripe 2` (>=2)
- `replica 3` or `replica 3 arbiter 1`

相同卷的复本不能在同一个节点上。

## 整合容器

研究GlusterFS就是为了给容器提供共享存储，所以需要与Kubernetes整合。

### 方案一

由上面的例子我们知道GlusterFS可以直接挂载到宿主机目录，并且了解k8s或者docker的同学也知道容器是可以直接使用宿主机目录的。所以，整合起来非常的简单。

> docker

```
docker run -d -p 80:80 -v /tmp/glusterfs/volume:/data nginx
```

> k8s pod

```
apiVersion: extensions/v1beta1
kind: Deployment
metadata:
  name: nginx
  namespace: default
spec:
  replicas: 1
  template:
    metadata:
      labels:
        k8s-app: nginx
    spec:
      containers:
      - name: nginx
        image: nginx
        volumeMounts:
        - mountPath: /data
          name: gluster-storage
      volumes:
      - name: gluster-storage
        hostPath: 
          path: "/tmp/glusterfs/volume"
```

需要先将glusterfs volume挂载到每个宿主机的目录，然后再将宿主机目录挂载到pod中。

这种方式的缺点就是需要给每个宿主机去配置挂载，相对比较繁琐。

### 方案二

针对k8s解决方案。

https://github.com/kubernetes/examples/tree/master/staging/volumes/glusterfs

可以将glusterfs直接挂载到pod中进行使用。

仍然以nginx部署为例，使用我们上面创建的dsrv卷做存储。

glusterfs-endpoints.json

```
{
  "kind": "Endpoints",
  "apiVersion": "v1",
  "metadata": {
    "name": "glusterfs-cluster"
  },
  "subsets": [
    {
      "addresses": [
        {
          "ip": "10.211.55.11"
        }
      ],
      "ports": [
        {
          "port": 1
        }
      ]
    },
    {
      "addresses": [
        {
          "ip": "10.211.55.12"
        }
      ],
      "ports": [
        {
          "port": 1
        }
      ]
    },
    {
      "addresses": [
        {
          "ip": "10.211.55.14"
        }
      ],
      "ports": [
        {
          "port": 1
        }
      ]
    }
  ]
}
```

glusterfs-svc.json

```
{
  "kind": "Service",
  "apiVersion": "v1",
  "metadata": {
    "name": "glusterfs-cluster"
  },
  "spec": {
    "ports": [
      {"port": 1}
    ]
  }
}
```

glusterfs-pod.json

```
{
  "apiVersion": "v1",
  "kind": "Pod",
  "metadata": {
    "name": "glusterfs"
  },
  "spec": {
    "containers": [
      {
        "name": "glusterfs",
        "image": "nginx:alpine",
        "ports": [
          {
            "containerPort": 80,
            "hostPort": 80
          }
        ],
        "volumeMounts": [
          {
            "mountPath": "/usr/share/nginx/html",
            "name": "glusterfsvol"
          }
        ]
      }
    ],
    "volumes": [
      {
        "name": "glusterfsvol",
        "glusterfs": {
          "endpoints": "glusterfs-cluster",
          "path": "dsrv"
        }
      }
    ]
  }
}
```

## 问题排查

gluster使用了若干端口，如果出现probe peer或数据无法同步，考虑iptables对应用的影响。

查看卷日志：

```
gluster volume log rotate myvol  #实现日志rotate
```

添加卷提示路径已在卷中的错误

执行下面的脚本，清除历史数据及属性信息

```
path=$1 #参数为待添加目录绝对路径  
rm -rf $path/.glu*  
setfattr -x trusted.glusterfs.volume-id $path  
setfattr -x trusted.gfid $path 
``` 

添加卷连接失败

每次向卷中添加brick后，远端的glusterd进程可能会连接关闭一段时间。此时执行操作会提示连接失败。等一会再执行即可。

Peer in Cluster (Disconnected) 问题

http://blog.chinaunix.net/xmlrpc.php?r=blog/article&uid=21142030&id=5296522

## 参考资料

- [gluster 官方文档](http://docs.gluster.org/en/latest/)
- [gluster deb包下载地址](http://ppa.launchpad.net/gluster/glusterfs-3.10/ubuntu/pool/main/g/glusterfs/)
- [gluster 依赖包下载](http://archive.ubuntu.com/ubuntu/pool/main/)
- [GlusterFS分布式文件系统使用简介](http://blog.csdn.net/zzulp/article/details/39527441)
- [Ubuntu下安装GlusterFS](http://blog.csdn.net/zhaihaifei/article/details/62429122)
- [基于 GlusterFS 实现 Docker 集群的分布式存储](https://www.ibm.com/developerworks/cn/opensource/os-cn-glusterfs-docker-volume/index.html?lnk=hm)
- [glusterfs-rest](https://github.com/aravindavk/glusterfs-rest)
- [ubuntu系统下安装glusterfs](http://blog.csdn.net/xuzhouweihao/article/details/26583493)
- [基于分布式文件系统+GlusterFS+的安全技术研究](http://www.doc88.com/p-3354307411329.html)