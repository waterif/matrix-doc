# k8s calico网络测试

我们的集群结构为2台物理机，每台物理机分配4台虚拟机。

- 101,102,103,104 在物理机1
- 113,114,115,116 在物理机2

在104,114,115,116四台机器上新搭建了一个calico网络的集群。

在104,114,116机器上安装qperf.

```
wget https://mirrors.aliyun.com/ubuntu/pool/universe/q/qperf/qperf_0.4.10-1_amd64.deb
dpkg -i qperf_0.4.10-1_amd64.deb
```

我们将进行如下实验：

1. 104,114,116节点间测试
2. 114上的Pod访问114,104,116节点测试
3. 114上的Pod访问114,104,116上的Pod测试

## 准备Pod

> qperf-1.yaml

```
apiVersion: v1
kind: Pod
metadata:
  name: qperf-1
spec:
  nodeSelector:
    kubernetes.io/hostname: k8s-114
  containers:
  - image: 10.255.1.101/infra/qperf
    name: qperf-1
    imagePullPolicy: IfNotPresent
    command:
    - sleep
    - "3600"
```

> qperf-2.yaml

```
apiVersion: v1
kind: Pod
metadata:
  name: qperf-2
  labels:
    k8s-app: qperf-2
spec:
  nodeSelector:
    kubernetes.io/hostname: k8s-114
  containers:
  - image: 10.255.1.101/infra/qperf
    name: qperf-2
    imagePullPolicy: IfNotPresent
    command:
    - qperf
    - "-lp"
    - "19765"
    ports:
    - containerPort: 19765
      name: "p1udp"
      protocol: UDP
    - containerPort: 19765
      name: "p1tcp"
      protocol: TCP
    - containerPort: 19766
      name: "p2tcp"
      protocol: TCP
    - containerPort: 19766
      name: "p2udp"
```

> qperf-3.yaml

```
apiVersion: v1
kind: Pod
metadata:
  name: qperf-3
  labels:
    k8s-app: qperf-3
spec:
  nodeSelector:
    kubernetes.io/hostname: k8s-104
  containers:
  - image: 10.255.1.101/infra/qperf
    name: qperf-3
    imagePullPolicy: IfNotPresent
    command:
    - qperf
    - "-lp"
    - "19765"
    ports:
    - containerPort: 19765
      name: "p1udp"
      protocol: UDP
    - containerPort: 19765
      name: "p1tcp"
      protocol: TCP
    - containerPort: 19766
      name: "p2tcp"
      protocol: TCP
    - containerPort: 19766
      name: "p2udp"
```

> qperf-4.yaml

```
apiVersion: v1
kind: Pod
metadata:
  name: qperf-4
  labels:
    k8s-app: qperf-4
spec:
  nodeSelector:
    kubernetes.io/hostname: k8s-116
  containers:
  - image: 10.255.1.101/infra/qperf
    name: qperf-4
    imagePullPolicy: IfNotPresent
    command:
    - qperf
    - "-lp"
    - "19765"
    ports:
    - containerPort: 19765
      name: "p1udp"
      protocol: UDP
    - containerPort: 19765
      name: "p1tcp"
      protocol: TCP
    - containerPort: 19766
      name: "p2tcp"
      protocol: TCP
    - containerPort: 19766
      name: "p2udp"
```

pod列表：

```
kubectl get pod -o wide
NAME      READY     STATUS    RESTARTS   AGE       IP               NODE
qperf-1   1/1       Running   0          14s       172.11.168.130   k8s-114
qperf-2   1/1       Running   0          14s       172.11.168.129   k8s-114
qperf-3   1/1       Running   0          14s       172.11.60.0      k8s-104
qperf-4   1/1       Running   0          14s       172.11.65.192    k8s-116
```

## 实验1

104,114,116三台机器上均启动qperf. 另外开个114的终端分别执行：

```
qperf -v 10.255.1.114 tcp_bw tcp_lat
qperf -v 10.255.1.116 tcp_bw tcp_lat
qperf -v 10.255.1.104 tcp_bw tcp_lat
```

各执行3-5次，统计记录。

## 实验2

进入到qperf-1容器中，分别测试104,114,116三台节点的网络情况。

```
kubectl exec -it qperf-1 /bin/bash
qperf -v 10.255.1.114 tcp_bw tcp_lat
qperf -v 10.255.1.116 tcp_bw tcp_lat
qperf -v 10.255.1.104 tcp_bw tcp_lat
```

各执行3-5次，统计记录。

## 实验3

进入到qperf-1容器中，分别测试104,114,116三台节点上的Pod的网络情况。

```
kubectl exec -it qperf-1 /bin/bash
qperf -v 172.11.168.129 tcp_bw tcp_lat
qperf -v 172.11.65.192 tcp_bw tcp_lat
qperf -v 172.11.60.0 tcp_bw tcp_lat
```

各执行3-5次，统计记录。

升级

上面只是简单的测试，可以将测试用的指令换一下，进一步测试网络性能。

## 实验1+

104,114,116三台机器上均启动qperf. 另外开个114的终端分别执行：

```
qperf -v 10.255.1.114 -m 64K -t 10 tcp_bw tcp_lat
qperf -v 10.255.1.116 -m 64K -t 10 tcp_bw tcp_lat
qperf -v 10.255.1.104 -m 64K -t 10 tcp_bw tcp_lat
```

## 实验2+

进入到qperf-1容器中，分别测试104,114,116三台节点的网络情况。

```
kubectl exec -it qperf-1 /bin/bash
qperf -v 10.255.1.114 -m 64K -t 10 tcp_bw tcp_lat
qperf -v 10.255.1.116 -m 64K -t 10 tcp_bw tcp_lat
qperf -v 10.255.1.104 -m 64K -t 10 tcp_bw tcp_lat
```

## 实验3+

进入到qperf-1容器中，分别测试104,114,116三台节点上的Pod的网络情况。

```
kubectl exec -it qperf-1 /bin/bash
qperf -v 172.11.168.129 -m 64K -t 10 tcp_bw tcp_lat
qperf -v 172.11.65.192 -m 64K -t 10 tcp_bw tcp_lat
qperf -v 172.11.60.0 -m 64K -t 10 tcp_bw tcp_lat

## 实验1++

104,114,116三台机器上均启动qperf. 另外开个114的终端分别执行：

```
qperf -v 10.255.1.114 -oo msg_size:1:64K:*4 tcp_bw tcp_lat
qperf -v 10.255.1.116 -oo msg_size:1:64K:*4 tcp_bw tcp_lat
qperf -v 10.255.1.104 -oo msg_size:1:64K:*4 tcp_bw tcp_lat
```

## 实验2++

进入到qperf-1容器中，分别测试104,114,116三台节点的网络情况。

```
kubectl exec -it qperf-1 /bin/bash
qperf -v 10.255.1.114 -oo msg_size:1:64K:*4 tcp_bw tcp_lat
qperf -v 10.255.1.116 -oo msg_size:1:64K:*4 tcp_bw tcp_lat
qperf -v 10.255.1.104 -oo msg_size:1:64K:*4 tcp_bw tcp_lat
```

## 实验3++

进入到qperf-1容器中，分别测试104,114,116三台节点上的Pod的网络情况。

```
kubectl exec -it qperf-1 /bin/bash
qperf -v 172.11.168.129 -oo msg_size:1:64K:*4 tcp_bw tcp_lat
qperf -v 172.11.65.192 -oo msg_size:1:64K:*4 tcp_bw tcp_lat
qperf -v 172.11.60.0 -oo msg_size:1:64K:*4 tcp_bw tcp_lat
```