# Nginx负载apiserver

说在前面：

nginx不适合负载kube-apiserver, 可以用是可以用，但是调度起来是相当的慢，这里只是讲如何用，好不好用另说。

不过nginx仅仅用来代理kube-apiserver还是可以的，但是给kubelet, kube-proxy, kube-controller-manager, kube-scheduler不建议使用nginx负载，而应该采用haproxy + keepalived实现。

nginx也是可以配置的，直接贴出示例：

```
# nginx https tls双向认证
server {
  listen 6443 ssl;
  listen [::]:6443 ssl;

  ssl on;
  ssl_certificate /etc/kubernetes/ssl/admin.pem;
  ssl_certificate_key /etc/kubernetes/ssl/admin-key.pem;
  ssl_client_certificate /etc/kubernetes/ssl/ca.pem;
  ssl_verify_client on;

  proxy_ssl_certificate /etc/kubernetes/ssl/admin.pem;
  proxy_ssl_certificate_key /etc/kubernetes/ssl/admin-key.pem;

  large_client_header_buffers 4 16k;
  client_max_body_size 300m;
  client_body_buffer_size 128k;
  proxy_connect_timeout 600;
  proxy_read_timeout 600;
  proxy_send_timeout 600;
  proxy_buffer_size 64k;
  proxy_buffers   4 32k;
  proxy_busy_buffers_size 64k;
  proxy_temp_file_write_size 64k;

  location / {
    proxy_pass https://apiserver;

    proxy_set_header X-SSL-Client-Cert $ssl_client_cert;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto  $scheme;
    #proxy_set_header Authorization "Bearer 547e7fd232eddaa4ec0303258088221c";

  }

}

# kube-apiserver
upstream apiserver {
  server  10.255.1.101:6443;
  server  10.255.1.102:6443;
  server  10.255.1.113:6443;
}

# nginx https basic认证
server {
  listen 8443 default_server;
  listen [::]:8443 default_server;

  root /var/www/html;
  index index.html index.htm index.nginx-debian.html;

  auth_basic on;
  auth_basic_user_file /etc/nginx/htpasswd;

  ssl on;
  ssl_certificate /etc/kubernetes/ssl/admin.pem;
  ssl_certificate_key /etc/kubernetes/ssl/admin-key.pem;

  large_client_header_buffers 4 16k;
  client_max_body_size 300m;
  client_body_buffer_size 128k;
  proxy_connect_timeout 600;
  proxy_read_timeout 600;
  proxy_send_timeout 600;
  proxy_buffer_size 64k;
  proxy_buffers   4 32k;
  proxy_busy_buffers_size 64k;
  proxy_temp_file_write_size 64k;

  location / {
    proxy_pass https://apiserver;

    proxy_set_header X-SSL-Client-Cert $ssl_client_cert;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto  $scheme;
    proxy_set_header Authorization "Bearer 547e7fd232eddaa4ec0303258088221c";
    #proxy_set_header Authorization $http_authorization;

  }

}
```