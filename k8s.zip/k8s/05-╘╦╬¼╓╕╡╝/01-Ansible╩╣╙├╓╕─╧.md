Ansible 使用指南

在CentOS系统上安装ansible

```
yum install epel-release
yum install ansible -y
```

配置ansible到需要连接的主机免密码登录。

```
# 生成ssh密钥
ssh-keygen -t rsa -P '' -f ~/.ssh/id_rsa
# 复制ssh密钥到远程主机
ssh-copy-id -i ~/.ssh/id_rsa.pub remoteuser@remoteserver

或者尝试
ssh-keygen -t dsa -P '' -f ~/.ssh/id_dsa
cat ~/.ssh/id_dsa.pub >> ~/.ssh/authorized_keys
chmod 600 ~/.ssh/authorized_keys # 或者644
```

配置主机目录

```
more /etc/ansible/hosts 
# This is the default ansible 'hosts' file.
#
# It should live in /etc/ansible/hosts
#
#   - Comments begin with the '#' character
#   - Blank lines are ignored
#   - Groups of hosts are delimited by [header] elements
#   - You can enter hostnames or ip addresses
#   - A hostname/ip can be a member of multiple groups

# Ex 1: Ungrouped hosts, specify before any group headers.

## green.example.com
## blue.example.com
## 192.168.100.1
## 192.168.100.10

# Ex 2: A collection of hosts belonging to the 'webservers' group

## [webservers]
## alpha.example.org
## beta.example.org
## 192.168.1.100
## 192.168.1.110

# If you have multiple hosts following a pattern you can specify
# them like this:

## www[001:006].example.com

# Ex 3: A collection of database servers in the 'dbservers' group

## [dbservers]
## 
## db01.intranet.mydomain.net
## db02.intranet.mydomain.net
## 10.25.1.56
## 10.25.1.57

# Here's another example of host ranges, this time there are no
# leading 0s:

## db-[99:101]-node.example.com

[k8s]
10.255.1.94
10.255.1.95
10.255.1.96
```

ansible的命令格式：

```
ansible <host-pattern> [options]
```

检查ansible安装环境

检查所有的远程主机，是否以root用户创建了ansible管理主机可以访问的环境

```
ansible all -m ping -u root
10.255.1.95 | SUCCESS => {
    "changed": false, 
    "failed": false, 
    "ping": "pong"
}
10.255.1.96 | SUCCESS => {
    "changed": false, 
    "failed": false, 
    "ping": "pong"
}
10.255.1.94 | SUCCESS => {
    "changed": false, 
    "failed": false, 
    "ping": "pong"
}
```

执行命令

在所有主机上，默认以当前bash的同名用户，在远程主机上执行

```
ansible all -a "echo hello"
10.255.1.94 | SUCCESS | rc=0 >>
hello
10.255.1.95 | SUCCESS | rc=0 >>
hello
10.255.1.96 | SUCCESS | rc=0 >>
hello
```

复制文件

复制一个文件到k8s机组

```
ansible k8s -m copy -a "src=~/abc.txt dest=~/"
10.255.1.95 | SUCCESS => {
    "changed": true, 
    "checksum": "03cfd743661f07975fa2f1220c5194cbaff48451", 
    "dest": "/root/abc.txt", 
    "failed": false, 
    "gid": 0, 
    "group": "root", 
    "md5sum": "0bee89b07a248e27c83fc3d5951213c1", 
    "mode": "0644", 
    "owner": "root", 
    "size": 4, 
    "src": "/root/.ansible/tmp/ansible-tmp-1509148656.41-133665927098212/source", 
    "state": "file", 
    "uid": 0
}
10.255.1.96 | SUCCESS => {
    "changed": true, 
    "checksum": "03cfd743661f07975fa2f1220c5194cbaff48451", 
    "dest": "/root/abc.txt", 
    "failed": false, 
    "gid": 0, 
    "group": "root", 
    "md5sum": "0bee89b07a248e27c83fc3d5951213c1", 
    "mode": "0644", 
    "owner": "root", 
    "size": 4, 
    "src": "/root/.ansible/tmp/ansible-tmp-1509148656.41-94529138170554/source", 
    "state": "file", 
    "uid": 0
}
10.255.1.94 | SUCCESS => {
    "changed": true, 
    "checksum": "03cfd743661f07975fa2f1220c5194cbaff48451", 
    "dest": "/root/abc.txt", 
    "failed": false, 
    "gid": 0, 
    "group": "root", 
    "md5sum": "0bee89b07a248e27c83fc3d5951213c1", 
    "mode": "0644", 
    "owner": "root", 
    "size": 4, 
    "src": "/root/.ansible/tmp/ansible-tmp-1509148656.37-27468412252828/source", 
    "state": "file", 
    "uid": 0
}
```

查看几台机器中已经有了abc.txt.

添加用户

```
ansible all -m user -a "name=foo password=<crypted password here>"
```

启动服务

```
ansible k8s -m service -a "name=etcd state=started"
```

并行执行

```
ansible lb -a "/sbin/reboot" -f 10
```

查看远程主机的全部系统信息

```
ansible all -m setup
# 内容略多
```

上面对命令有了一个初步的认识。

使用脚本管理主机

为了避免重复地输入命令，ansible提供了脚本功能。脚本的名字叫playbook, 使用YAML格式。

执行脚本的方法：

```
ansible-playbook deploy.yml
```

脚本包含几个关键字：

- hosts: 某主机的IP，或者主机组名，或者all
- remote_user: 以某个用户身份执行
- vars: 变量
- tasks: playbook的核心，定义顺序执行的动作Action. 
- handlers: playbook的event处理操作，在被action触发时才会执行，多次触发只执行一次，并按照声明的顺序执行。


action语法：

```
module: module_parameter=module_value
```

常用的模块有：yum, copy, template等。

查看ansible的模块。

在命令行使用模块

```
ansible servers -m 模块名字 -a 模块的参数
```

ping 模块

```
ansible servers -m ping
```

在playbook脚本中使用模块

tasks中的每一个action都是对模块的一次调用，在每个action中：

- 冒号前面是模块的名字
- 冒号后面是调用模块的参数

```
- hosts: k8s
  tasks:
  - debug:
      msg: "System {{inventory_hostname}} has gateway {{ansible_default_ipv4.gateway}}"
```

debug模块

通过参数msg定义打印的字符串。msg中可以嵌入变量。

通过var定义需要打印的变量。

打印系统变量

```
- hosts: k8s
  tasks:
  - debug:
      var: hostvars[inventory_hostname]["ansible_default_ipv4"]["gateway"]
```

打印动态注入的变量

```
- hosts: k8s
  tasks:
  - shell: /usr/bin/uptime
    register: result
  - debug:
      var: result
```

copy 模块

复制静态文件到远程节点上，并且设置合理的文件权限。

设置文件权限
利用mode设置权限，可以是数字，也可以是符号的形式"u=rw,g=r,o=r"和"u+rw,g-wx,o-rwx".

```
- hosts: 10.255.1.95
  tasks:
  - copy:
      src: /root/abc.txt
      dest: /root/abcd.txt
      owner: root
      group: root
      mode: 0644
```

备份节点上原来的文件

backup参数为yes时，如果发生复制操作，先复制目标节点上的源文件，当两个文件相同时，不再进行复制操作。

```
- hosts: 10.255.1.95
  tasks:
  - copy:
      src: /root/abc.txt
      dest: /root/abcd.txt
      backup: yes
```

正在95节点上执行查看。

```
ls
abcd.txt  abcd.txt.8505.2017-11-02@04:20:35~
```

template模块

如果需要在复制的时候修改部分内容，那么就需要template模块。

比如安装apache后，你需要给节点复制一个测试页面index.html. index.html里面需要显示当前节点的主机名和IP，这时候就用到template.

如index.html.j2 (template使用的是python的jinja2引擎)

```
Served by {{ansible_hostname}} ({{ansible_default_ipv4.address}}).
```

ansible_hostname 和 ansible_default_ipv4.address 都是远程主机的系统变量，ansible会自动帮我们搜索并替换。

我们也可以使用自定义的变量。

index.html.j2

```
Served by {{ansible_hostname}} ({{ansible_default_ipv4.address}}) at {{http_port}}, user: {{remote_user}}.
```

```
- hosts: 10.255.1.95
  vars:
    http_port: 8080
    remote_user: root
  tasks:
  - template:
      src: /root/ansible/template/index.html.j2
      dest: /root/index.html
      backup: yes
```

```
more /root/index.html
Served by node1 (10.255.1.95) at 8080, user: root.
```

file 模块

可以用来设置远程主机上的文件，软连接和文件夹的权限，也可以用来创建和删除他们。

改变文件权限

```
- hosts: 10.255.1.95
  tasks:
  - file:
      path: /root/index.html
      mode: 0644
      #mode: "u=rw,g=r,o=r"
      #mode: "u+rw,g-rw,o-rwx"
```

创建文件的软连接

```
- hosts: 10.255.1.95
  tasks:
  - file:
      src: /root/index.html
      dest: /root/index.html.lnk
      state: link
```

创建一个新文件

```
- hosts: 10.255.1.95
  tasks:
  - file:
      path: /root/index2.html
      state: touch
      mode: "u=rw,g=r,o=r"
```

创建新的文件夹

```
- hosts: 10.255.1.95
  tasks:
  - file:
      path: /root/new_dir
      state: directory
      mode: 0755
```

用户模块

可以增，删，改linux远程节点的用户账户，并为其设置账户的属性。

增加账户

```
- user:
    name: johnd
    comment: "John Doe"
    uid: 1040
    group: admin
```

创建账号，并将其添加到两个group中

```
- user:
    name: johnd
    shell: /bin/bash
    groups: admins, devs
    append: yes
```

删除账户

```
- user:
    name: johnd
    state: absent
    remove: yes
```

修改账户属性

为用户创建一个2048位的SSH密钥，放置到~/.ssh/id_rsa中

```
- user:
    name: johnd
    generate_ssh_key: yes
    ssh_key_bits: 2048
    ssh_key_file: .ssh/id_rsa
```

为用户添加过期时间

```
- user:
    name: johnd
    shell: /bin/zsh
    groups: devs
    expires: 1400000000
```

yum 模块，暂不介绍。

service 服务管理模块
该模块用来管理远程节点上的服务，如httpd, sshd, nfs, crond等。

开，关，重启，重载服务。

```
- service:
    name: httpd
    state: started

- service:
    name: httpd
    state: stopped

- service:
    name: httpd
    state: restarted

- service:
    name: httpd
    state: reloaded
```

设置开机启动服务

```
- service:
    name: httpd
    enabled: yes
```

启动网络服务下的接口eth0

```
- service:
    name: network
    state: restarted
    args: eth0
```

firewalld模块不太熟，略过。

shell 模块

在远程节点上通过/bin/sh执行命令。
支持 HOME < > | ; &.

```
- shell: echo "Test1" > ~/test1

- shell: service jboss start && chkconfig jboss on

- shell: echo foo >> ~/test1
```

调用脚本

```
- shell: somescript.sh >> somelog.txt
```

在执行脚本前改变工作目录。

```
- shell: somescript.sh >> somelog.txt
  args:
    chdir: somedir/
```

在执行命令前改变工作目录，并且仅在somelog.txt不存在时执行命令。

```
- shell: somescript.sh >> somelog.txt
  args:
    chdir: somedir/
    creates: somelog.txt
```

指定bash运行命令

```
- shell: cat < /tmp/\*txt
  args:
    executable: /bin/bash
```

command略过。

ansible配置文件的优先级（从高到低）

- ANSIBLE_CONFIG
- ansible.cfg: 当前目录下的cfg文件
- .ansible.cfg: 当前目录下的.cfg文件
- /etc/ansible/ansible.cfg

主机清单

默认文件

/etc/ansible/hosts

命令行传递配置文件

ansible-playbook -i hosts site.yml











